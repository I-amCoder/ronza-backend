<?php $__env->startSection('settings', 'active'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-dark">Site Settings</h2>
        </div>
        <hr>
        <form action="<?php echo e(route('site.settings.update', encrypt($site->id))); ?>" class="mb-5" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <?php echo $__env->make('site.partials.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <hr>
            <?php echo $__env->make('site.partials.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <hr>
            <?php echo $__env->make('site.partials.images', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <hr>
            <div class="row mt-4">
                <div class="col text-center">
                    <Button class="btn btn-success" type="submit">Save</Button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ronza\Ronza\resources\views/site/settings.blade.php ENDPATH**/ ?>