<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <h2>Manage Products</h2>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-danger">
                    <i class="fa fa-backward"></i>
                    Back
                </a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-12">
                <div class="card shadow">
                    <div class="card-header">
                        <h5>Add New Product</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('products.partials.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <hr>
                            <?php echo $__env->make('products.partials.description', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <hr>
                            <?php echo $__env->make('products.partials.images', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="row mt-4">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-success">Save </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <!-- include summernote css/js -->

    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <?php echo $__env->make('site.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ronza\Ronza\resources\views/products/create.blade.php ENDPATH**/ ?>