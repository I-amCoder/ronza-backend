<?php $__env->startSection('categories', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <h4>Manage Categories</h4>
                <hr>
                <button class="btn btn-success" data-toggle="modal" data-target="#AddCategoryModal">Add New
                    Category</button>
            </div>
        </div>
        <div class="row">

            <div class="col-12 mt-3">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <th></th>
                            <th>Name</th>

                            <th>Title</th>
                            <th>Actions</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo e($category->logo_path); ?>" alt="<?php echo e($category->name); ?>"
                                            class="img-table-sm">
                                    </td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><?php echo e($category->title); ?></td>
                                    <td>
                                        <button data-name="<?php echo e($category->name); ?>" data-title="<?php echo e($category->title); ?>"
                                            data-logo="<?php echo e($category->logo_path); ?>" data-id="<?php echo e(encrypt($category->id)); ?>"
                                            class="btn btn-sm btn-warning editCategory"><i class="fa fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <?php echo $__env->make('category.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.partials.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $('.editCategory').click(function() {
            $("#editCatName").val($(this).data('name'));
            $("#editCatTitle").val($(this).data('title'));
            $("#editImage").attr('src', $(this).data('logo'));
            let id = $(this).data('id');
            console.log($("#" + id).value);
            $("#edit-category-from").attr('action', "<?php echo e(url('category')); ?>/" + id);
            $("#editCategoryModal").modal('show');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ronza\Ronza\resources\views/category/index.blade.php ENDPATH**/ ?>