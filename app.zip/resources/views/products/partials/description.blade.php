<div class="row">
    <div class="col-12">
        <h5>Description</h5>
    </div>
    <div class="col-12">
        <textarea id="summernote" name="editordata"></textarea>
    </div>
</div>
